package com.example.edu_sys;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EduSysApplicationTests {

	@Test
	void contextLoads() {
	}

}
