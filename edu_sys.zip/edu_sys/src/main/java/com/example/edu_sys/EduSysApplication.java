package com.example.edu_sys;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EduSysApplication {

	public static void main(String[] args) {
		SpringApplication.run(EduSysApplication.class, args);
	}

}
